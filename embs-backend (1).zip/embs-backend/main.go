package main

import (
	"heathcare/server"
)

func main() {

	// run server on port APP_PORT
	server.RunServer()
}
